# not working for me but included for completeness
# Error: Could not find or load main class —cp
java —cp lib -jar generateTripData.jar data/free-zipcode-database-Primary.csv data/vehicles-nodups.csv data/trip-locations.csv 1000
