java -jar $JETTY_HOME/start.jar --module=http,deploy,plus,servlet,webapp

